-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2020 at 12:27 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `datamahasiswa`
--

-- --------------------------------------------------------

--
-- Table structure for table `dat_mhs`
--

CREATE TABLE `dat_mhs` (
  `nim` varchar(30) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `matkul1` varchar(30) NOT NULL,
  `nilai1` int(11) NOT NULL,
  `matkul2` varchar(30) NOT NULL,
  `nilai2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dat_mhs`
--

INSERT INTO `dat_mhs` (`nim`, `nama`, `matkul1`, `nilai1`, `matkul2`, `nilai2`) VALUES
('123', 'Bambang', 'PBO', 90, 'PW', 65),
('456', 'Anisa', 'SCPK', 80, 'OPK', 70),
('789', 'Sukinem', 'KALKULUS', 70, 'ANALOG', 80),
('789', 'Dinda', 'A', 90, 'B', 70),
('9999', 'AAA', 'BBB', 90, 'CCC', 90),
('123', 'aa', 'xx', 90, 'dd', 90),
('123456', 'Juminten', 'PBO', 90, 'PW', 70),
('123180042', 'NURUL AINIA SEPTIANA', 'PBO', 90, 'PW', 80);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
